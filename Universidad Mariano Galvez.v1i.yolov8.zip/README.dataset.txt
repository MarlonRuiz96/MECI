# Universidad Mariano Galvez > 2024-10-25 3:12am
https://universe.roboflow.com/umg-tclba/universidad-mariano-galvez

Provided by a Roboflow user
License: CC BY 4.0

